# 安全与脱敏规范

## 公开归档禁止项

- API Key、Secret、Token、Cookie、Authorization 头和签名结果
- `.env`、密钥文件、浏览器 profile、缓存、登录二维码和会话快照
- 飞书 app/base/table/view/file/folder/chat 等资源标识
- 微信 AppID、素材 ID、草稿 ID、用户标识和发布凭据
- 腾讯云、火山引擎及第三方平台的账号、密钥和私有 URL
- 客户手机号、联系人、企业线索原表、聊天记录和内部销售备注
- 员工录音、音色 ID、生物特征素材及未获公开授权的图片/视频
- 平台原始响应、调试包、下载目录、截图和生成成片

## 可以保留的内容

- 功能定义、流程、输入输出和故障降级策略
- 脱敏后的脚本名称、模块职责和依赖名称
- 环境变量名称，但不得保留变量值
- 已公开的品牌名、产品类别和一般应用场景
- 合规边界、审批要求和人工复核节点

## 环境变量命名参考

以下仅为变量名示例，仓库中不得出现真实值：

```text
WECHAT_APP_ID
WECHAT_APP_SECRET
WECHAT_API_KEY
ARK_API_KEY
VOLC_SPEECH_APP_ID
VOLC_SPEECH_ACCESS_TOKEN
TENCENTCLOUD_SECRET_ID
TENCENTCLOUD_SECRET_KEY
TENCENT_COS_BUCKET
TENCENT_COS_REGION
FEISHU_APP_ID
FEISHU_APP_SECRET
TIKHUB_API_KEY
```

## 上线前检查

1. 对提交内容运行密钥扫描和高熵字符串检查。
2. 搜索 `token`、`secret`、`password`、`cookie`、`authorization`、手机号和 URL 查询参数。
3. 检查 Git 历史，而不仅是当前文件；密钥一旦进入历史应立即轮换。
4. 确认所有外发内容均有来源、无虚构事实，并经过负责人审批。
5. 确认自动发布、付费 API 和客户触达行为具有明确授权与成本上限。

## 运营合规边界

- 仅使用合法公开数据，不绕过登录、验证码、付费墙或平台限制。
- 不调用未经授权的私有接口，不规避平台风控。
- 不复制他人文章、视频、广告或海报；只抽取可泛化的结构和方法。
- 不将“相似”描述为“官方合作”，不暗示未经证实的品牌关系。
- 对技术参数、认证、客户案例、价格和交期保持可追溯。
