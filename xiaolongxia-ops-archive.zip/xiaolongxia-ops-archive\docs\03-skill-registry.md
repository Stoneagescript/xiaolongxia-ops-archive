# Skill 注册表

这里的 Skill 是已经实际使用过、可被重新封装为自动化能力的工作单元。

| Skill ID | 触发场景 | 输入 | 输出 |
| --- | --- | --- | --- |
| `brand-ops-memory` | 任何汉北电气运营任务 | 长期指令、品牌资料 | 品牌一致的执行上下文 |
| `feishu-knowledge-sync` | 整理或同步资料 | 飞书文档、云盘、表格 | 知识索引和结构化记录 |
| `product-doc-parser` | 新增产品资料 | 图片、PDF、说明书 | 参数摘要、疑点清单 |
| `cad-ocr-analyst` | 图纸或扫描件解析 | DWG/DXF/PDF/图片 | OCR 文本、图层和尺寸信息 |
| `wechat-draft-publisher` | 公众号内容任务 | 标题、正文、封面 | 草稿或预览 |
| `limyai-relay-publisher` | 需要中转发布 | 图文内容、授权配置 | 中转任务结果 |
| `xhs-content-publisher` | 小红书日更 | 产品资料、选题、参考内容 | A/B 文案、图片、发布包 |
| `douyin-h-table-researcher` | 抖音热点任务 | 关键词、公开热点源 | H 表热点记录 |
| `j-table-lead-qualification` | 潜客开发任务 | 公开企业信息 | 去重并分级的 J 表线索 |
| `sales-copywriter` | 宣传或销售沟通 | 场景、痛点、产品能力 | 短文案和销售话术 |
| `ad-style-rotator` | 需要避免文案同质化 | 主题、近 14 日内容 | 风格轮换后的文案 |
| `poster-mimic-designer` | 给定参考海报 | 参考图、产品图、品牌信息 | 原创同语言海报方案 |
| `video-generation-producer` | 营销视频任务 | 脚本、图片、提示词 | 任务 ID、视频和状态 |
| `voiceover-producer` | 视频配音与后期 | 授权音色、文案、视频 | 配音和合成成片 |
| `cloud-asset-ops` | 素材需云端中转 | 本地素材、对象路径 | COS 地址与上传结果 |
| `browser-cdp-operator` | 平台仅提供网页操作 | 已授权浏览器会话 | 自动提交、轮询、下载 |
| `automation-maintainer` | 日/周定时任务 | cron 计划、运行策略 | 任务状态、日志和通知 |
| `github-archive-publisher` | 能力需要沉淀归档 | 已脱敏文档与索引 | GitHub/ZIP 归档 |

## 12 类广告语言风格

1. 误诊反转
2. 泰式反转
3. 港式极简
4. 工程师诊断
5. 场景微短剧
6. 类比解释
7. 选型避坑
8. 克制高级
9. 轻喜剧
10. 未来工业
11. 对比清单
12. 温和推动

风格库只决定叙事方式，不改变产品事实。每次生成需参考近 14 日内容，避免连续重复同一结构。

## 潜客分级原则

- A 级：目标行业明确、存在工业电加热或功率控制需求、联系方式公开且可核验。
- B 级：行业匹配但需求或联系方式不完整，需要后续确认。
- C 级：相关性弱、重复、同业/贸易商/控制系统厂商，或公开信息不足。
