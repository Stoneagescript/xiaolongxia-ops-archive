# 运行手册与源文件索引

本页记录原工作区中形成能力的主要文件名，便于在私有环境中继续维护。文件内容未原样放入公开归档，避免硬编码标识、凭据或业务数据被误传。

## 总指令与知识规则

- `小龙虾-汉北电气长期运营指令.md`
- `openclaw_product_docs_periodic.md`
- `hanbei-ad-language-knowledge-base.md`
- `short_promotional_copy_logic_cross.md`
- `poster_mimic_logic.md`

## 微信公众号

- `wechat_service_account_runbook.md`
- `wechat_service_account_publisher.js`
- `limyai_wechat_publisher.py`

主流程：准备图文 → 获取授权 → 上传封面/正文图片 → 创建草稿 → 预览/人工确认 → 必要时发布。

## 小红书

- `xhs_daily_publisher_runbook.md`
- `hanbei_xhs_asset_generator.js`
- `xhs_collect_competitors.js`

主流程：读取产品资料与选题 → 生成 A/B 文案 → 制作 1080×1440 视觉 → 校验品牌与事实 → 发布或输出发布包。

## 抖音热点与内容研究

- `douyin_table_h_hot_video_runbook.md`
- `collect_douyin_content.js`
- `douyin_hot_multisource_probe.py`
- `write_free_hot_items_to_table_h.py`
- `tikhub_weekly_douyin_hot.js`

主流程：多源检索 → 去重和相关性判断 → 摘要原创化 → 写入飞书 H 表 → 记录来源与时间。

## 潜在客户 J 表

- `g_table_j_potential_customer_runbook.md`
- `collect_g_table_j_potential_customers.py`
- `build_local_j_candidates_from_b.py`
- `split_j_records_to_b_c.py`
- `regrade_j_by_phone_and_review.py`
- `promote_b_to_a_by_same_mobile.py`
- `verify_local_j_candidates_to_feishu.py`

主流程：公开来源采集 → 行业/角色排除 → 联系方式核验 → 查重 → A/B/C 分级 → 写入飞书 → 抽样复核。

## 视频、配音与云素材

- `volcengine_video_and_douyin_hot_research.md`
- `voiceover_pipeline.md`
- `ark_seedance_video.js`
- `jimeng_daily_video.js`
- `jimeng_public_beta_video.js`
- `pippit_marketing_video.js`
- `poll_pippit_task.js`
- `cos_upload_assets.js`
- CDP/Updream 浏览器操作脚本

主流程：脚本和提示词 → 素材上传 → 创建生成任务 → 轮询 → 下载 → 授权音色配音 → FFmpeg 合成 → 质检。

## 产品文档与 CAD

- `cad_extract_dxf.py`
- 飞书产品资料扫描、同步和 cron 安装脚本
- PDF/OCR/CAD 转换辅助脚本

主流程：发现新资料 → 下载 → 类型识别 → 文本/OCR/CAD 提取 → 结构化参数 → 不确定项标记 → 飞书同步。

## 技术依赖

工作区 Node 依赖主要包括 `@volcengine/openapi` 与 `puppeteer-core`；其他外部工具包括 Python、FFmpeg、Tesseract、Poppler、LibreDWG/ODA 和 ezdxf。具体版本应在重建时重新锁定并做安全扫描。
